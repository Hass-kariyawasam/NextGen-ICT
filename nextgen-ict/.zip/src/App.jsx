import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Box, CircularProgress, Typography, Button } from '@mui/material';
import { AuthContextProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import ThemeContextProvider from './context/ThemeContext';

import Home from './pages/Home';
import SignIn from './pages/SignIn';
import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminOrdersPage from './pages/admin/AdminOrdersPage';
import DashboardLMS from './pages/DashboardLMS';

import './App.css';

function ProtectedRoute({ children, requireAdmin = false }) {
  const { user, userData, loadingUser } = useAuth();

  if (loadingUser) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', gap: 2, bgcolor: '#F8FAFC' }}>
        <CircularProgress size={50} sx={{ color: '#2563EB' }} />
        <Typography sx={{ color: '#64748b', fontSize: '0.9rem' }}>Preparing your dashboard...</Typography>
      </Box>
    );
  }

  if (!user) {
    return <Navigate to="/signin" replace />;
  }

  if (requireAdmin && userData?.role !== 'admin') {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', p: 4, textAlign: 'center' }}>
        <Typography variant="h5" sx={{ color: '#EF4444', fontWeight: 700, mb: 2 }}>Access Denied</Typography>
        <Typography sx={{ color: '#64748b', mb: 3 }}>This page requires administrator privileges.</Typography>
        <Button variant="contained" onClick={() => window.location.href = '/dashboard-lms'} sx={{ borderRadius: '10px', textTransform: 'none' }}>Go to Student Dashboard</Button>
      </Box>
    );
  }

  return children;
}

function App() {
  return (
    <Router>
      <ThemeContextProvider>
        <AuthContextProvider>
          <CartProvider>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/signin" element={<SignIn />} />
              <Route path="/admin" element={<AdminLogin />} />
              <Route path="/admin/dashboard" element={<ProtectedRoute requireAdmin><AdminDashboard /></ProtectedRoute>} />
              <Route path="/admin/orders" element={<ProtectedRoute requireAdmin><AdminOrdersPage /></ProtectedRoute>} />
              <Route path="/dashboard-lms/*" element={<ProtectedRoute><DashboardLMS /></ProtectedRoute>} />
              <Route path="*" element={<Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', p: 4, textAlign: 'center' }}><Typography variant="h1" sx={{ fontSize: '6rem', fontWeight: 900, color: '#e2e8f0' }}>404</Typography><Typography variant="h5" sx={{ color: '#64748b', mb: 3 }}>Page not found</Typography><Button variant="contained" onClick={() => window.location.href = '/'} sx={{ borderRadius: '10px', textTransform: 'none' }}>Go to Home</Button></Box>} />
            </Routes>
          </CartProvider>
        </AuthContextProvider>
      </ThemeContextProvider>
    </Router>
  );
}

export default App;